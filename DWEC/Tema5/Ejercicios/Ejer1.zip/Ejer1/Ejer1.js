$(document).ready(
    function(){
        let enlaces = $('a').lenght;
        alert("Numero de enlaces: " + enlaces);
    }
);