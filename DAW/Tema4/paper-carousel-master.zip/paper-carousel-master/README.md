# paper-carousel
[![Build Status](https://travis-ci.org/wincinderith/paper-carousel.svg?branch=master)](https://travis-ci.org/wincinderith/paper-carousel)

Polymer element that displays a Material Design image carousel.
Read the docs [here](https://wincinderith.github.io/paper-carousel).
